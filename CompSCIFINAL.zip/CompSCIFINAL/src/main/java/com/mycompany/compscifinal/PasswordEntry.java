/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.compscifinal;

/**
 *
 * @author CMcPhail2026
 */
public class PasswordEntry {
    private String username;
    private String label; // e.g., "Gmail", "Work VPN"
    private String passwordValue;

    public PasswordEntry(String username, String label, String passwordValue) {
        this.username = username;
        this.label = label;
        this.passwordValue = passwordValue;
    }

    public String getUsername() {
        return username;
    }

    public String getLabel() {
        return label;
    }

    public String getPasswordValue() {
        return passwordValue;
    }

    @Override
    public String toString() { // For display in JList
        return "Label: " + label + " - Password: " + passwordValue;
    }
}
